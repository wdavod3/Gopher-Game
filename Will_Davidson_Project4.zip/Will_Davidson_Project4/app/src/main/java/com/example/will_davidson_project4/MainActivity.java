package com.example.will_davidson_project4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    /*Declare the buttons for the game modes*/
    Button turn;
    Button contin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*Set the values for the two buttons*/
        turn = (Button) findViewById(R.id.button);
        contin = (Button) findViewById(R.id.button4);


        /*Turn by Turn mode*/
        turn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent game = new Intent(MainActivity.this, GopherGame.class);
                game.putExtra("Game Option", false);
                startActivity(game);
            }//end of onClick
        });

        /*Continuous mode*/
        contin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent game = new Intent(MainActivity.this, GopherGame.class);
                game.putExtra("Game Option", true);
                startActivity(game);
            }//onClick()
        });

    }//end of onCreate()
}//end of MainActivity