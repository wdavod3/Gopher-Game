package com.example.will_davidson_project4;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Random;

public class GopherGame extends AppCompatActivity {

    /*The holes for the game*/
    ArrayList<GopherHole> hole0;

    /*The buttons for the actions*/
    Button nextTurn;
    Button newGame;

    /*Different Integers used for gameplay*/
    Integer gopher;
    Integer turn;
    Integer click1;
    Integer click2;

    /*Check if the game is continuous or turn by turn*/
    Boolean option;

    /*Used to save the values checked for the second thread*/
    ArrayList<Integer> click2Nums;

    /*Used for displaying the holes*/
    ArrayList<TextView> holes;


    /*Set up handler for the game*/
    private final Handler gopherHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message message) {
            int what = message.what ;
            switch (what) {
                /*If the hole is picked by the first thread*/
                case PICK_HOLE_1:
                    holes.get(click1).setText(hole0.get(click1).getStatus());
                    holes.get(click1).setTextColor(hole0.get(click1).getColor());
                    break;
                /*If the hole is picked by the second thread*/
                case PICK_HOLE_2:
                    holes.get(click2).setText(hole0.get(click2).getStatus());
                    holes.get(click2).setTextColor(hole0.get(click2).getColor());
                    break;
                /*If the gopher if found by one of the threads*/
                case GOPHER_FOUND:
                    newGame.setEnabled(true);
                    nextTurn.setEnabled(false);
                    break;
            }//end of switch case

        }//end of handleMessage
    };


    /*Set the values for the switch cases*/
    public static final int PICK_HOLE_1 = 0 ;
    public static final int PICK_HOLE_2 = 1;
    public static final int GOPHER_FOUND = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        /*Declare the buttons and their status*/
        nextTurn = (Button)findViewById(R.id.button2);
        newGame = (Button)findViewById(R.id.button3);
        newGame.setEnabled(false);

        /*Used to determine which hole the gopher is in*/
        gopher = new Random().nextInt(99 - 0);

        /*Used for the threads to check each gopher hole*/
        click1 = -1;
        click2 = new Random().nextInt(99 - 0);
        click2Nums = new ArrayList<>();
        click2Nums.add(click2);

        /*Used to check which game mode was chosen*/
        Intent game = getIntent();
        option = (Boolean) game.getSerializableExtra("Game Option");

        /*Used to decide which thread's turn it is*/
        turn = 1;

        /*The ArrayList used to hold the gopher holes*/
        hole0 = new ArrayList<>();

        /*The ArrayList used to display the gopher holes*/
        holes = new ArrayList<>();
        holes.add(findViewById(R.id.hole0));
        holes.add(findViewById(R.id.hole1));
        holes.add(findViewById(R.id.hole2));
        holes.add(findViewById(R.id.hole3));
        holes.add(findViewById(R.id.hole4));
        holes.add(findViewById(R.id.hole5));
        holes.add(findViewById(R.id.hole6));
        holes.add(findViewById(R.id.hole7));
        holes.add(findViewById(R.id.hole8));
        holes.add(findViewById(R.id.hole9));
        holes.add(findViewById(R.id.hole10));
        holes.add(findViewById(R.id.hole11));
        holes.add(findViewById(R.id.hole12));
        holes.add(findViewById(R.id.hole13));
        holes.add(findViewById(R.id.hole14));
        holes.add(findViewById(R.id.hole15));
        holes.add(findViewById(R.id.hole16));
        holes.add(findViewById(R.id.hole17));
        holes.add(findViewById(R.id.hole18));
        holes.add(findViewById(R.id.hole19));
        holes.add(findViewById(R.id.hole20));
        holes.add(findViewById(R.id.hole21));
        holes.add(findViewById(R.id.hole22));
        holes.add(findViewById(R.id.hole23));
        holes.add(findViewById(R.id.hole24));
        holes.add(findViewById(R.id.hole25));
        holes.add(findViewById(R.id.hole26));
        holes.add(findViewById(R.id.hole27));
        holes.add(findViewById(R.id.hole28));
        holes.add(findViewById(R.id.hole29));
        holes.add(findViewById(R.id.hole30));
        holes.add(findViewById(R.id.hole31));
        holes.add(findViewById(R.id.hole32));
        holes.add(findViewById(R.id.hole33));
        holes.add(findViewById(R.id.hole34));
        holes.add(findViewById(R.id.hole35));
        holes.add(findViewById(R.id.hole36));
        holes.add(findViewById(R.id.hole37));
        holes.add(findViewById(R.id.hole38));
        holes.add(findViewById(R.id.hole39));
        holes.add(findViewById(R.id.hole40));
        holes.add(findViewById(R.id.hole41));
        holes.add(findViewById(R.id.hole42));
        holes.add(findViewById(R.id.hole43));
        holes.add(findViewById(R.id.hole44));
        holes.add(findViewById(R.id.hole45));
        holes.add(findViewById(R.id.hole46));
        holes.add(findViewById(R.id.hole47));
        holes.add(findViewById(R.id.hole48));
        holes.add(findViewById(R.id.hole49));
        holes.add(findViewById(R.id.hole50));
        holes.add(findViewById(R.id.hole51));
        holes.add(findViewById(R.id.hole52));
        holes.add(findViewById(R.id.hole53));
        holes.add(findViewById(R.id.hole54));
        holes.add(findViewById(R.id.hole55));
        holes.add(findViewById(R.id.hole56));
        holes.add(findViewById(R.id.hole57));
        holes.add(findViewById(R.id.hole58));
        holes.add(findViewById(R.id.hole59));
        holes.add(findViewById(R.id.hole60));
        holes.add(findViewById(R.id.hole61));
        holes.add(findViewById(R.id.hole62));
        holes.add(findViewById(R.id.hole63));
        holes.add(findViewById(R.id.hole64));
        holes.add(findViewById(R.id.hole65));
        holes.add(findViewById(R.id.hole66));
        holes.add(findViewById(R.id.hole67));
        holes.add(findViewById(R.id.hole68));
        holes.add(findViewById(R.id.hole69));
        holes.add(findViewById(R.id.hole70));
        holes.add(findViewById(R.id.hole71));
        holes.add(findViewById(R.id.hole72));
        holes.add(findViewById(R.id.hole73));
        holes.add(findViewById(R.id.hole74));
        holes.add(findViewById(R.id.hole75));
        holes.add(findViewById(R.id.hole76));
        holes.add(findViewById(R.id.hole77));
        holes.add(findViewById(R.id.hole78));
        holes.add(findViewById(R.id.hole79));
        holes.add(findViewById(R.id.hole80));
        holes.add(findViewById(R.id.hole81));
        holes.add(findViewById(R.id.hole82));
        holes.add(findViewById(R.id.hole83));
        holes.add(findViewById(R.id.hole84));
        holes.add(findViewById(R.id.hole85));
        holes.add(findViewById(R.id.hole86));
        holes.add(findViewById(R.id.hole87));
        holes.add(findViewById(R.id.hole88));
        holes.add(findViewById(R.id.hole89));
        holes.add(findViewById(R.id.hole90));
        holes.add(findViewById(R.id.hole91));
        holes.add(findViewById(R.id.hole92));
        holes.add(findViewById(R.id.hole93));
        holes.add(findViewById(R.id.hole94));
        holes.add(findViewById(R.id.hole95));
        holes.add(findViewById(R.id.hole96));
        holes.add(findViewById(R.id.hole97));
        holes.add(findViewById(R.id.hole98));
        holes.add(findViewById(R.id.hole99));

        /*Set up all the gopher holes*/
        for (int i = 0; i < 100; ++i) {
            GopherHole adder = new GopherHole();
            adder.setHole(i + 1);
            hole0.add(i, adder);

            /*Set gopher*/
            if (i == gopher) {
                hole0.get(i).setGopher();
            }//end of if

        }//end of for loop

        /*Set the status for all the other holes that aren't the gopher*/
        setGopherStatus(gopher, hole0);

        /*Use to progress each turn*/
        nextTurn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*For continuous mode*/
                if (option) {
                    thread1();
                    try { Thread.sleep(1000); }
                    catch (InterruptedException e) { System.out.println("Thread interrupted!") ; }
                    thread2();
                }//end of if

                /*Turn by Turn mode*/
                else {
                    /*Thread 1's turn*/
                    if (turn % 2 == 1) { thread1(); }

                    /*Thread 2's turn*/
                    else { thread2(); }

                    /*Increase turn number*/
                    turn++;

                }//end of else
            }//end of onCLick()
        });

        /*Take the user back to main activity to choose game mode*/
        newGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newGame = new Intent(GopherGame.this, MainActivity.class);
                startActivity(newGame);
            }//end of onClick
        });

    }//end of onCreate


    /*Runnable for first thread*/
    public class GopherRunnable1 implements Runnable {

        @Override
        public void run() {

            /*Check if second thread has checked that hole*/
            if (hole0.get(click1).getClicked2()) {
                //Set status to disaster
                hole0.get(click1).setStatus(5);
            }//end of if

            /*Set up message to send to handler*/
            Message message = gopherHandler.obtainMessage(PICK_HOLE_1);

            /*Delay the thread*/
            try { Thread.sleep(1000); }
            catch (InterruptedException e) { System.out.println("Thread interrupted!") ; }

            /*Make is so this hole has been checked by thread 1*/
            hole0.get(click1).setClicked1();

            /*Send the hole status to the handler*/
            gopherHandler.sendMessage(message) ;

            /*If the hole checked was the gopher hole*/
            if (hole0.get(click1).getGopher()) {
                //Tell handler the gopher was found
                message = gopherHandler.obtainMessage(GOPHER_FOUND);
                gopherHandler.sendMessage(message) ;
            }//end of if


        }//end of run()
    }//end of GopherRunnable1

    /*Use for the second thread*/
    public class GopherRunnable2 implements Runnable {

        @Override
        public void run() {

            /*Check if the first thread has already checked that hole*/
            if (hole0.get(click1).getClicked1()) {
                //Change hole's status
                hole0.get(click1).setStatus(5);
            }//end of if

            /*Set up status message to send to handler*/
            Message message = gopherHandler.obtainMessage(PICK_HOLE_2);

            /*Delay the thread*/
            try { Thread.sleep(1000); }
            catch (InterruptedException e) { System.out.println("Thread interrupted!") ; }

            /*Make hole checked by thread 2*/
            hole0.get(click2).setClicked2();

            /*Send status message to handler*/
            gopherHandler.sendMessage(message) ;

            /*If the hole has the gopher*/
            if (hole0.get(click2).getGopher()) {
                //Tell handler gopher was found
                message = gopherHandler.obtainMessage(GOPHER_FOUND);
                gopherHandler.sendMessage(message);
            }//end of if


        }//end of run()
    }//end of GopherRunnable2

    /*Use to run Thread 1*/
    public void thread1 () {
        Thread t1 = new Thread(new GopherRunnable1());
        t1.start();

        /*Keep moving horizontally*/
        click1++;
    }//end of thread1()

    /*Use to run Thread 2*/
    public void thread2() {
        Thread t2 = new Thread(new GopherRunnable2());
        t2.start();

        /*Keep checking the holes randomly*/
        click2 = new Random().nextInt(99 - 0);

        /*If thread 2 has already checked that hole*/
        if (click2Nums.contains(click2)) {

            /*Keep going until a hole has been found that hasn't been checked*/
            while (click2Nums.contains(click2)) {
                click2 = new Random().nextInt(99 - 0);
            }//end of while
            click2Nums.add(click2);
        }//end of if
        /*Thread 2 has not checked that hole*/
        else {
            click2Nums.add(click2);
        }//end of else
    }//end of thread2()

    /*Use to set the status of all the holes for the gopher game*/
    public void setGopherStatus (Integer check, ArrayList<GopherHole> hole) {

        Log.i("Gopher", "Gopher status has been called");

        /*Loop for all the gopher holes*/
        for (int i = 0; i < 100; ++i) {
            /*Use to set status of the gopher hole*/
            if (hole.get(i).getGopher()) {
                hole.get(i).setStatus(1);
                Log.i("Gopher", "There's a gopher");
            }//end of if

            /*Use to set status of the Near Miss holes*/
            else if ( ( i == check - 11 ) ||  ( i == check - 10) ||
                     ( i == check - 9 ) || ( ( i == check + 1 ) ||
                     ( i == check + 11 ) ) || ( ( i == check + 10 ) ||
                     ( i == check + 9 ) ) || ( ( i == check - 1 ))
            ) {
                hole.get(i).setStatus(2);
            }//end of else if

            /*Use to set status of the Close Guess holes*/
            else if ( ( i == check - 20 ) || ( i == check - 19 ) ||
                    ( i == check - 18 ) || ( i == check - 8 )||
                    ( i == check + 2 ) || ( i == check + 12 ) ||
                    ( i == check + 22 ) || ( i == check + 21 ) ||
                    ( i == check + 20 ) || ( i == check + 19 ) ||
                    ( i == check + 18 ) || ( i == check + 8 )||
                    ( i == check - 2 ) || ( i == check - 12 ) ||
                    ( i == check - 22 ) || ( i == check - 21 )
            ) {
                hole.get(i).setStatus(3);
            }//end of else if

            /*Use to set status of the Complete Miss holes*/
            else {
                hole.get(i).setStatus(4);
            }//end of else
        }//end of for

    }//end of SetGopherStatus

}//end of GopherGame
