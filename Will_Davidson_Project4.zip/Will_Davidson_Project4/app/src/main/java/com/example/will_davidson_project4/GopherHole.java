package com.example.will_davidson_project4;

public class GopherHole {

    private Boolean gopher;
    private String status;
    private Boolean clicked1;
    private Boolean clicked2;
    private Integer color;
    private Integer holeNum;


    /*Set the initial state of each gopher hole variable*/
    public void setHole(Integer num) {

        this.gopher = false;
        this.status = "";
        this.clicked1 = false;
        this.clicked2 = false;
        this.color = 0x00000000;
        this.holeNum = num;
    }//end of setHole

    /*If selected by thread 1*/
    public void setClicked1() {
        this.clicked1 = true;
        this.clicked2 = false;
        this.color = 0xffff0000;
    }//end of setClicked1()

    /*If selected by thread 2*/
    public void setClicked2() {
        this.clicked1 = false;
        this.clicked2 = true;
        this.color = 0xff00ffff;
    }//end of setClicked2()

    /*If the hole is the gopher hole*/
    public void setGopher() { this.gopher = true; }

    /*Use for setting each hole's status*/
    public void setStatus(Integer status) {
        /*Gopher hole*/
        if (status == 1) { this.status = "S"; }
        /*Near Miss*/
        else if (status == 2) { this.status = "N"; }
        /*Close Guess*/
        else if (status == 3) { this.status = "Cl"; }
        /*Complete Miss*/
        else if (status == 4) { this.status = "C"; }
        /*Disaster*/
        else if (status == 5) { this.status = "D"; }
    }//end of setStatus()
/*------------------------------------------------------------------------------------------------*/
    /*If the hole is the gopher hole or not*/
    public Boolean getGopher() { return this.gopher; }

    /*Get the status of the hole*/
    public String getStatus() { return status; }

    /*If the hole was selected by the first thread*/
    public Boolean getClicked1() { return clicked1; }

    /*If the hole was selected by the second thread*/
    public Boolean getClicked2() { return clicked2; }

    /*Use to distinguish which thread selected the hole*/
    public Integer getColor() { return color; }

    /*Use to figure out the placement of the hole on the grid*/
    public Integer getHoleNum() { return holeNum; }
}
